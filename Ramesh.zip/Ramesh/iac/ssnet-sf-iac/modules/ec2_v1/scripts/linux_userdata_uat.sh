#!/bin/bash
set -o xtrace
echo "Set aws region"
/usr/local/bin/aws configure set default.region ap-southeast-1
# setting system time in SGT
timedatectl set-timezone Asia/Singapore

#Set hostname
hostnamectl set-hostname --static apm

sed -i 's/use_fully_qualified_names = True/use_fully_qualified_names = False/g' /etc/sssd/sssd.conf
sed -i 's/\/home\/%u@%d/\/home\/%u/g' /etc/sssd/sssd.conf
systemctl restart sssd
systemctl daemon-reload

cp /inventory/uat/os/sshd_config /etc/ssh/sshd_config
cp /inventory/uat/os/sudoers /etc/sudoers
systemctl restart sshd

cp /inventory/uat/os/config.json /opt/aws/amazon-cloudwatch-agent/bin/config.json

# Cloudwatch agent config
mkdir -p /usr/share/collectd/
touch /usr/share/collectd/types.db
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c file:///opt/aws/amazon-cloudwatch-agent/bin/config.json
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a start
