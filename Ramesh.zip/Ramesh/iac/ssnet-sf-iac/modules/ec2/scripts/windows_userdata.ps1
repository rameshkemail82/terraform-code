<powershell>
########################
Write-Output "Userdata execution started..."

Set-DefaultAWSRegion -Region ap-southeast-1
Set-Variable -name random -value (Get-Random -minimum 101 -maximum 999)

Write-Output "Cloud watch agent config..."
cd D:\inventory\${env}\
& "C:\Program Files\Amazon\AmazonCloudWatchAgent\amazon-cloudwatch-agent-ctl.ps1" -a fetch-config -m ec2 -s -c file:cloudwatch.json
& "C:\Program Files\Amazon\AmazonCloudWatchAgent\amazon-cloudwatch-agent-ctl.ps1" status

Write-Output "Set VM name"
Rename-Computer -NewName ${vm_name}-$random

</powershell>