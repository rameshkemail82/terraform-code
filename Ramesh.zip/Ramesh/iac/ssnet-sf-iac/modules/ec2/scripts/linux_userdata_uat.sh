#!/bin/bash
set -o xtrace
echo "Running user-data script on $(date)" | tee -a /var/log/user-data.log
LOGFILE="/var/log/user-data.log"


echo "Set AWS region"
/usr/local/bin/aws configure set default.region ap-southeast-1

# Set system time to Singapore Time (SGT)
timedatectl set-timezone Asia/Singapore

# Set hostname
hostnamectl set-hostname --static dedicated-runner

#updated the json file
if [[ -f /inventory/uat/os/config.json ]]; then
    cp /inventory/uat/os/config.json /opt/aws/amazon-cloudwatch-agent/bin/config.json
else
    echo "Warning: /inventory/uat/os/config.json not found. Skipping CloudWatch Agent configuration." | tee -a $LOGFILE
fi

# Cloudwatch agent setup
mkdir -p /usr/share/collectd/
touch /usr/share/collectd/types.db
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c file:///opt/aws/amazon-cloudwatch-agent/bin/config.json
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a start

# Set environment variable
# env="uat" # Change this to "prod" or "dev" as needed

# CWS, VMS, and ABLR onboarding - applicable only to UAT and PROD
if [[ "$env" == "dev" ]]; then
    echo "Skipping VMS and CloudOne onboarding in $env" | tee -a $LOGFILE
else
    echo "CloudOne onboarding in $env.." | tee -a $LOGFILE

    cws_hostedzone_id="uat.casecentral.cloudonegcc.com"
    cws_tenant_id="458D28E5-F7E6-C18D-CBDF-68CE8E686FF1"
    cws_token_id="C1F3EEE5-AAAD-473E-3261-F4A6C0D953A4"
    cws_policy_id="1"

    sudo /opt/ds_agent/dsa_control -r 2>&1 | tee -a $LOGFILE
    sudo /opt/ds_agent/dsa_control -x dsm_proxy://${cws_hostedzone_id}:3128/ 2>&1 | tee -a $LOGFILE
    sudo /opt/ds_agent/dsa_control -y relay_proxy://${cws_hostedzone_id}:3128/ 2>&1 | tee -a $LOGFILE
    sudo /opt/ds_agent/dsa_control -a "dsm://agents.workload.sg-1.cloudone.trendmicro.com:443/" \
        "tenantID:$cws_tenant_id" "token:$cws_token_id" "policyid:$cws_policy_id" 2>&1 | tee -a $LOGFILE

    echo "VMS onboarding in $env.." | tee -a $LOGFILE
    if [[ -x /opt/nessus_agent/sbin/nessuscli ]]; then
        sudo /opt/nessus_agent/sbin/nessuscli agent link \
            --key=1417b900619acd09dd63d2a066853fcb6c5b8a981798bd9eb194a69228706d13 \
            --groups="MSF-AWS" --host=10.191.17.158 --port=8834 2>&1 | tee -a $LOGFILE
        sudo /opt/nessus_agent/sbin/nessuscli agent status 2>&1 | tee -a $LOGFILE
    else
        echo "Warning: /opt/nessus_agent/sbin/nessuscli not found or not executable. Skipping VMS onboarding." | tee -a $LOGFILE
    fi
fi

echo "User-data script execution completed at $(date)" | tee -a $LOGFILE