# Add roles as administrator

Using the profile that creates the cluster,

```
aws eks --region ap-southeast-1 update-kubeconfig --name "eks-ssnet-prdizit-aiz" --kubeconfig "~/.kube/158787_config" --profile ssnet_devops
kubectl edit -n kube-system configmap/aws-auth --kubeconfig ~/.kube/158787_config
```

Then, add the following role map

```
    - groups:
      - system:masters
      rolearn: arn:aws:iam::391583854055:role/SSNet_Assume_EKS_AccessRole
      username: SSNet_Assume_EKS_AccessRole
```

# Install load balancer controller

```
cat >aws-load-balancer-controller-service-account.yaml <<EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/name: aws-load-balancer-controller
  name: aws-load-balancer-controller
  namespace: kube-system
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::391583854055:role/eks-IngressControllerRole-ssnet-prdizit-aiz
EOF

kubectl apply -f aws-load-balancer-controller-service-account.yaml --kubeconfig ~/.kube/158787_config
```

Then,
```
helm repo add eks https://aws.github.io/eks-charts

helm repo update

helm upgrade -i aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=eks-ssnet-prdizit-aiz \
  --set image.repository=391583854055.dkr.ecr.ap-southeast-1.amazonaws.com/eks-addons \
  --set image.tag=ssnetone-alb-controller-2.4.1 \
  --set serviceAccount.create=false \
  --set serviceAccount.name=aws-load-balancer-controller \
  --set region=ap-southeast-1 \
  --set vpcId=vpc-0c130bf0be40b090e \
  --kubeconfig ~/.kube/158787_config \
  --atomic --cleanup-on-fail --timeout 300s
```

# Restart coredns to run on Fargate private cluster

```
kubectl patch deployment coredns -n kube-system --type=json -p='[{"op": "remove", "path": "/spec/template/metadata/annotations", "value": "eks.amazonaws.com/compute-type"}]' --kubeconfig ~/.kube/158787_config
```

Then, update the image referenced in the deployment.
```
kubectl edit -n kube-system deployment/coredns --kubeconfig ~/.kube/158787_config
```

For example,
```
391583854055.dkr.ecr.ap-southeast-1.amazonaws.com/eks-addons:ssnetone-coredns-v1.8.7-eksbuild.1
```

```
kubectl rollout restart -n kube-system deployment coredns --kubeconfig ~/.kube/158787_config
```