#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Variables
#LOCAL_CHART_PATH="./oauth-server"  # Path to local Helm chart
RELEASE_NAME="${1}"  # Release name
CONFIRM_DEPLOYMENT="${2:-NO}"
ENV="${3:-dev}"
NAMESPACE="${4:-app}"  # Namespace
LOCAL_CHART_PATH="./${RELEASE_NAME}"

# Check if the release is passed as input
if [ -z "$1" ]; then
  echo "Error: Release name not provided. Please pass the required variable."
  exit 1
fi

# Check for Helm installation
if ! command -v helm &> /dev/null
then
    echo "==== Helm is not installed. Please install it from https://helm.sh ===="
    exit 1
fi

# Ensure the local chart path exists
if [ ! -d "$LOCAL_CHART_PATH" ]; then
  echo "==== Error: Local chart path '$LOCAL_CHART_PATH' does not exist ===="
  exit 1
fi

# Create namespace if it doesn't exist
if ! kubectl get namespace "$NAMESPACE" &> /dev/null; then
  echo "==== Namespace: $NAMESPACE does not exist ===="
 # kubectl create namespace "$NAMESPACE"  # Don't create ns as its done separately during initial EKS provisioning
  exit 1
else
  echo "==== Namespace '$NAMESPACE' already exists ===="
fi

# Intentionally allow args to split
# shellcheck disable=SC2046
HELM_INSTALL_DEFAULT_ARGS="${RELEASE_NAME} ${LOCAL_CHART_PATH} --values=${LOCAL_CHART_PATH}/${ENV}_values.yaml --namespace=${NAMESPACE}"

# Intentionally allow args to split
# shellcheck disable=SC2046,SC2086
echo "==== See helm diff changes prior to deployment ===="
helm diff upgrade --install --context 5 --suppress-secrets ${HELM_INSTALL_DEFAULT_ARGS} 

# Install or upgrade the Helm chart from local directory
# echo "==== Installing/upgrading Helm chart from local path '$LOCAL_CHART_PATH' in namespace '$NAMESPACE' ===="
# helm upgrade --install ${HELM_INSTALL_DEFAULT_ARGS} --wait --timeout 1m
# echo "==== Helm chart installation complete! ===="

if [[ "$CONFIRM_DEPLOYMENT" == "NO" ]]; then
  echo "==== Confirm deployment is set as NO.. Hence exiting..! ===="
  exit 0
else
  echo "==== Confirm deployment is set as YES or not NO.. Proceeding with deployment ===="
  echo "==== Installing/upgrading Helm chart from local path '$LOCAL_CHART_PATH' in namespace '$NAMESPACE' ===="
  echo "==== Executing command helm upgrade --install ${HELM_INSTALL_DEFAULT_ARGS} --atomic --wait --timeout 2m ===="
  helm upgrade --install ${HELM_INSTALL_DEFAULT_ARGS} --atomic --wait --timeout 2m
  echo "==== Helm chart installation complete! ===="
fi