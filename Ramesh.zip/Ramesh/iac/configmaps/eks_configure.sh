#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

function configure_eks() {
    [[ -n "${EKS_CLUSTER_NAME}" ]] && aws eks update-kubeconfig --name "${EKS_CLUSTER_NAME}" --region ap-southeast-1
}